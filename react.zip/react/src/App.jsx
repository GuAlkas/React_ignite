import { RepositoryList } from './componentes/RepositoryList';
import './styles/global.scss';
import { Counter } from './componentes/Counter';

export function App() {

    return (
        <>
        <RepositoryList />,
        <Counter />
        </>
    
    )
}

