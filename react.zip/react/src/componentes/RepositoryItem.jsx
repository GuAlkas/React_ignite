export function RepositoryItem (props) {
    return (
        <li>
            <strong>{props.repository?.name ?? 'default'}</strong>
            <p> Forms in java</p>

            <a href="">
                Acessar repositorio
            </a>
        </li>
    );
}